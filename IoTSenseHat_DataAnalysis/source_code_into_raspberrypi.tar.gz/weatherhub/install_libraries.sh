echo Installing required PIP libraries

sudo pip3 install pyowm
sudo pip3 install paho-mqtt