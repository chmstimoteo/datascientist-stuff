cd /home/pi/workspace/weatherhub/weather_mqtt

python3 weather_mqtt.py sensor_openweather.json
#python3 weather_mqtt.py config_openweather.json
