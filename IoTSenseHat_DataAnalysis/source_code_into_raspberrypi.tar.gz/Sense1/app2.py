from sense_hat import SenseHat
from time import sleep

sense = SenseHat()

while True:
    t1= sense.get_temperature_from_humidity()
    t2= sense.get_temperature_from_pressure()
    t= sense.get_temperature()
    
    print("Pressure: ",t2)
    print("Humidity: ",t1)
    print("Temperature: ",t)
    
    sleep(3)
    
    
    
