from sense_hat import SenseHat
from time import sleep
from datetime import datetime
import json

sense = SenseHat()
pause= 5

room_number=""
latitude=0
longitude=0

with open('config.json',mode='r') as cfg:
    config= json.loads(cfg.read())
    for m,mval in enumerate(config):
        room_number=config[m]['attributes']['room_number']['N']
        latitude=config[m]['attributes']['latitude']['N']
        longitude=config[m]['attributes']['longitude']['N']
    cfg.close()
    
while True:
    t1= sense.get_temperature_from_humidity()
    t2= sense.get_temperature_from_pressure()
    t= round(sense.get_temperature(),1)
    h= round(sense.get_humidity(),1)
    p= round(sense.get_pressure(),1)
    ts= str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

    print("Timestamp: ",ts)
    print("RoomNumber: ",room_number)
    print("Latitude: ", latitude)
    print("Longitude: ", longitude)
    print("Pressure: ",p)
    print("Humidity: ",h)
    print("Temperature: ",t)
    
    message = "TS: " + str(ts) +", R: " + str(room_number) +", LA: " + str(latitude) +", LO: " + str(longitude) + ", T: " + str(t) + ", P: " + str(p) + ", H: " + str(h) + "\n"
    #sense.show_message(message, scroll_speed=0.03)
    
    with open('output.txt',mode='a') as fw:
        fw.write(message)
        fw.close()
    sleep(pause)