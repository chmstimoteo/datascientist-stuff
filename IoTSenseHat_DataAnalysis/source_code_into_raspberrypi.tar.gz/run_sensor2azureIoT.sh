cd /home/pi/workspace/senseHat2AzureIoT/device/samples

python3.4 iothub_client_sample.py -c "HostName=IOTHUB-CST2101.azure-devices.net;DeviceId=alma-pi;SharedAccessKey=in8MfjC893XABak2HRnpQl0DkdjeeryNUaxTWxD1qT0="
